function validateUserForm() {
    var name = document.getElementById("name").value;
    var uname = document.getElementById("uname").value;
    var email = document.getElementById("email").value;
    var pattern = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var res = pattern.test(email);
    var pass = document.getElementById("pass").value;
    var pattern2 = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;;
    var res2 = pattern2.test(pass);

    if (name == "") {
        document.getElementById("errname").innerHTML="Please enter name";
        return false;
    }
    if (uname.length < 4) {
      document.getElementById("erruname").innerHTML="Must be minimum 5 characters";
      return false;
    }
    if (!res) {
        document.getElementById("erremail").innerHTML="Email format is not correct";
        return false;
      }
    if (!res1) {
      document.getElementById("errpass").innerHTML="Password format is not correct";
      return false;
    }
}


   