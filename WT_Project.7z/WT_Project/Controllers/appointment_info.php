<?php  
     include '../Model/database.php';

     $name="";
     $err_name="";
     $mail="";
     $err_mail="";
     $phoneno="";
     $err_phoneno="";
     $disease="";
     $err_disease="";
     $apt="";
     $err_apt="";
     $err_db="";

     $hasError = false;

/***********************************Insert Hotel*************************************/

if(isset($_POST["Insert"]))
     {
           if(empty($_POST["name"]))
          {
               $err_name="Name Required";
               $hasError = true;
          }

          else
          {
               $name=$_POST["name"];
          }

          if(empty($_POST["mail"]))
          {
               $err_mail="Mail Required";
               $hasError = true;
          }

          else
          {
               $mail=$_POST["mail"];
          }

          if(empty($_POST["phone"]))
          {
               $err_phoneno="Phone Required";
               $hasError = true;
          }

          else
          {  
               $phoneno=$_POST["phoneno"];
          }
          if(empty($_POST["disease"]))
          {
               $err_disease="Disease Required";
               $hasError = true;
          }

          else
          {  
               $disease=$_POST["disease"];
          }
          if(empty($_POST["appointment_time"]))
          {
               $err_disease="Disease Required";
               $hasError = true;
          }

          else
          {  
               $disease=$_POST["disease"];
          }
          


        

          //Database

          if(!$hasError)
          { 
          
               $rs= insertHotel("$id","$name","$mail","$phoneno","$disease","$apt");
               
               if($rs===true)
               {
                    header("Location:../View/manager_home.php");
               }

               $err_db= $rs;

          }
     }

/**********************************************Update Hotel Room******************************* */

if(isset($_POST["Update"]))
     {
          if(empty($_POST["name"]))
          {
               $err_name="Name Required";
               $hasError = true;
          }

          else
          {
               $name=$_POST["name"];
          }

          if(empty($_POST["roomno"]))
          {
               $err_roomno="Room No Required";
               $hasError = true;
          }

          else
          {
               $roomno=$_POST["roomno"];
          }

          if(empty($_POST["descr"]))
          {
               $err_descr="Description Required";
               $hasError = true;
          }

          else
          {  
               $descr=$_POST["descr"];
          }
     

          //Database

          if(!$hasError)
          {
               $rs=updateHotel("$name","$roomno","$descr","$categories",$_POST["id"]);
               if($rs===true)
               {
                    header("Location:../View/manager_home.php");
               }

               $err_db= "Duplicate Data";
          }
     }

     function all_hotel_rooms()
     {
     	$query= "SELECT * from hotel_room";
     	return $rs= get($query);
     }

     function get_hotel_room($id)
     {
          $query= "SELECT * from hotel_room where id= '$id'";
          $rs= get($query);
          return $rs[0];
     }
     function insertHotel($id,$name,$roomno,$descr,$categories)
     {
          $query="INSERT INTO hotel_room VALUES('$id','$name','$roomno','$descr','$cate gories')";
          return execute($query);
     }

     function updateHotel($id,$name,$roomno,$descr,$categories)
     {
          $query = "UPDATE hotel_room set name='$name', roomno='$roomno', description='$descr',Category='$categories' Where id='$id'";
          return execute($query);
     }

?>