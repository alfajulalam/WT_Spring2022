<?php  
     include ('../Model/database.php');
     $id="";
     $err_id="";
     $name="";
     $err_name="";
     $phoneno="";
     $err_phoneno="";
     $age="";
     $err_age="";
     $disease="";
     $err_disease="";
     $treatment="";
     $err_treatment="";
     $err_db="";
     
    

     if(isset($_POST["fetch"])){
          $db = new DB();
          $connobj = $db->openCon();
  
          $Data = $db->fetchData($connobj, "patient");
          $db->closeCon($connobj);
  
          if($Data->num_rows > 0){
  
              echo "<table border='3' align='center' width='70%'>";
  
              
              echo "<tr>";
  
              echo "<td>";
              echo "id";
              echo "</td>";
              
              echo "<td>";
              echo "Name";
              echo "</td>";
              
              echo "<td>";
              echo "Phone";
              echo "</td>";
  
              echo "<td>";
              echo "Age";
              echo "</td>";
  
              echo "</tr>";
  
              while($row = $Data->fetch_assoc()){
                  
                  echo "<tr>";
  
                  echo "<td>";
                  echo $row["id"];
                  echo "</td>";
                  
                  echo "<td>";
                  echo $row["name"];
                  echo "</td>";
                  
                  echo "<td>";
                  echo $row["phoneno"];
                  echo "</td>";
                  
                  echo "<td>";
                  echo $row["age"];
                  echo "</td>";
  
                  echo "</tr>";
  
              }
  
              echo "</table>";
  
          }
          else{
              echo "no data found";
          }
      }
/***********************************Insert Patient*************************************/
if(isset($_POST["Insert"]))
    {
     if(empty($_POST["id"]))
     {
          $err_id="id Required";
          $hasError = true;
     }

     else
     {
          $id=$_POST["id"];
     }
           if(empty($_POST["name"]))
          {
               $err_name="Name Required";
               $hasError = true;
          }

          else
          {
               $name=$_POST["name"];
          }

          if(empty($_POST["phoneno"]))
          {
               $err_phoneno="Phone No Required";
               $hasError = true;
          }

          else
          {
               $phoneno=$_POST["phoneno"];
          }

          if(empty($_POST["age"]))
          {
               $err_age="Age Required";
               $hasError = true;
          }
          else
          {  
               $age=$_POST["age"];
          }
          if(empty($_POST["disease"]))
          {
               $err_disease="disease Required";
               $hasError = true;
          }
          else
          {  
               $disease=$_POST["disease"];
          }
          if(empty($_POST["treatment"]))
          {
               $err_treatment="Treatment Discription Required";
               $hasError = true;
          }
          else
          {  
               $treatment=$_POST["treatment"];
          }
          //Database

     $connection = new db();
     $conobj=$connection->OpenCon();
     $userQuery=$connection->Insertdata($conobj,"patient",$id,$name, $phoneno, $age,$disease,$treatment);
     if ($userQuery===TRUE)
      {
       $error = "User Data inserted";
      }
     else
     {
      $error = "User Data not inserted";
     }
     echo "*****************patient DATA INSERTED INTO DATABASE**********";
     $connection->closeCon($conobj);

    }

/***********************************Update patient*************************************/


if(isset($_POST["Update"]))
    {
     if(empty($_POST["id"]))
     {
          $err_id="id Required";
          $hasError = true;
     }

     else
     {
          $id=$_POST["id"];
     }
         
           if(empty($_POST["name"]))
          {
               $err_name="Name Required";
               $hasError = true;
          }

          else
          {
               $name=$_POST["name"];
          }

          if(empty($_POST["phoneno"]))
          {
               $err_phoneno="Phone No Required";
               $hasError = true;
          }

          else
          {
               $phoneno=$_POST["phoneno"];
          }

          if(empty($_POST["age"]))
          {
               $err_age="Age Required";
               $hasError = true;
          }
          else
          {  
               $age=$_POST["age"];
          }
          //Database

          $connection = new db();
          $conobj=$connection->OpenCon();
          $userQuery=$connection->updatedata($conobj,"patient",$id,$name, $phoneno, $age,$disease,$treatment);
          if ($userQuery===TRUE)
           {
            $error = "User Data inserted";
           }
          else
          {
           $error = "User Data not inserted";
          }
          echo "*****************patient DATA updated INTO DATABASE**********";
          $connection->closeCon($conobj);
    }

/***********************************Delete patient*************************************/


if(isset($_POST["Delete"]))
    {
     if(empty($_POST["id"]))
     {
          $err_id="id Required";
          $hasError = true;
     }

     else
     {
          $id=$_POST["id"];
     }
           if(empty($_POST["name"]))
          {
               $err_name="Name Required";
               $hasError = true;
          }

          else
          {
               $name=$_POST["name"];
          }

          if(empty($_POST["phoneno"]))
          {
               $err_phoneno="Phone No Required";
               $hasError = true;
          }

          else
          {
               $phoneno=$_POST["phoneno"];
          }

          if(empty($_POST["age"]))
          {
               $err_age="Age Required";
               $hasError = true;
          }
          else
          {  
               $age=$_POST["age"];
          }
          //Database

          if(!$hasError)
               {
                    $rs=deletepatient($_POST["id"]);
                    var_dump($rs);
                    if($rs===true)
                    {
                         header("Location:../View/homapage.php");
                    }
                    else{
                         $err_db= $rs;
                    }
               }
    }
    $connection = new db();
     $conobj=$connection->OpenCon();
     $userQuery=$connection->deleteData($conobj,"patient",$id);
     if ($userQuery===TRUE)
      {
       $error = "User Data inserted";
      }
     else
     {
      $error = "User Data not inserted";
     }

     $connection->closeCon($conobj);




    

?>
