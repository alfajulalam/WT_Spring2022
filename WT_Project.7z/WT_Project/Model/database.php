<?php
class DB{
 
	function OpenCon(){
		$dbhost = "localhost";
		$dbuser = "root";
		$dbpass = "";
		$db = "wt_project";
		$conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
		
		return $conn;
	}

	function closeCon($conn){
		$conn->close();
	}

	function InsertData($conn,$table,$id,$name,$phoneno,$age, $disease,$treatment){
		$result = $conn->query("INSERT INTO $table (id,name, phoneno,age,disease,treatment) VALUES ('$id','$name','$phoneno','$age', '$disease','$treatment')");
		return $result;
	}

	function fetchData($conn, $tablename){
		$sqlstr="SELECT * FROM $tablename";
		$results = $conn->query($sqlstr);
		return $results;
	}

	function updateData($conn, $patient, $id, $name, $phoneno, $age, $disease){
		$sqlstr = ("UPDATE $patient SET id='$id', name='$name', phoneno='$phoneno',age='$age', disease='$disease', WHERE age='$age'");
		$conn->query($sqlstr);

	}
	function deleteData($conn, $table, $id){
		$sqlstr = "DELETE FROM $table WHERE id='$id'";

		if($conn->query($sqlstr)){
			echo "Data deleted";
		}
		else{
			echo "Data not deleted".$conn->error;
		}
	}
	function searchUser($conn, $tablename, $fname){
        $sqlstr = "SELECT * FROM $tablename WHERE fname='$fname'";
        $results = $conn->query($sqlstr);
        return $results;
    }
	

}
?>