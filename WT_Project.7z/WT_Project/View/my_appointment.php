<!DOCTYPE html>
<html>
    <head>
        <title>MY APPOINTMENT</title>
    </head>
    <body>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
            </tr>
            <?php
            $conn =  mysqi_connect("localhost","root","","wt_project");
            if($conn->connect_error){
                die(("Connection failed:"), $conn-> connect_error);
            }
            $sql ="SELECT id,username,password from login";
            $result = $coon-> query($sql);

            if($result->num_rows>o){
                echo"<tr><td>."$row]["id"]."</td><td">.$row["username"]."</td><td>".$row["password"]."</td></tr>";
                
            ?>
            
                


            
         
        </table>
    </body>
</html>