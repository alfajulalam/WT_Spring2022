<html>

	<head>
		<link rel="stylesheet" href="mycss.css">
	</head>
	<body>
	
		<div class="header-index">
			<a class="btn"><b class="text-white name">Doctor</b></a>
			
		</div>