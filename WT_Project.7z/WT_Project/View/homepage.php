<html>
<head> 
<link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
    <h1 >DOCTOR | DASHBOARD</h1>
    <form action="" method="post">
  <table >
    <tr>
      
        <td>
         <div  class="btn-link">
      <a href="http://localhost/Wt_PROJECT/view/view_profile.php">My Profile </a>
        </td>
        <br></br>
    
         <td>
           <div  class="btn-link">
          <a href="http://localhost/Wt_PROJECT/view/my_appointment.php">My Appoinments> </a>
           </td>
           <br></br>
         
	  
      
	  <td>
	  <div  class="btn-link">
        <a href="http://localhost/WT_Project/Controllers/patient_info.php"> All Patient Info <br></a>
        </div>
      </td>
      <td>
	  <div  class="btn-link">
        <a href="http://localhost/WT_Project/View/add_patient.php"> Add Patient <br></a>
        </div>
      </td> <br>    
        <td>
            <div  class="btn-link"><a href="logout.php">LOG OUT <br></a></div>
        </td>
    </tr> 
        <td>
        <div  class="btn-link"><a href="search.php">Search <br></a></div>
        </td>
    </tr>
  </table>
</div>
</body>
</html>