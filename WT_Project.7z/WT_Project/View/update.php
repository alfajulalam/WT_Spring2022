<?php  
    include '../Controllers/patient_info.php';
     //$id= $_GET["id"];
     //$e= getpatient($id);
?>

<!DOCTYPE html>
<html>
<head>
     <title>Update Employee </title>
     <link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
      <form action="" method="post">
               <table >
               <?php echo $err_db;?> 
      	     	<input type="hidden" name="id" value="<?php echo $id?>">
                         <tr>
                         <td><h2 >Name:</h2></td>
                         <td>
                              <input type="text" name="name" value="<?php echo $name; ?>">
                              <span><?php echo $err_name;?></span>
                         </td>
                         </tr>

                         <tr>
                         <td><h2 >Phone no:</h2></td>
                         <td>
                              <input type="text" name="phoneno" value="<?php echo $phoneno; ?>">
                              <span><?php echo $err_phoneno;?></span>
                         </td>                    
                         </tr>

                         <tr>
                         <td><h2 >Age:</h2></td>
                         <td>
                              <input type="text" name="age" value="<?php echo $age;?>">
                              <span><?php echo $err_age;?></span>
                         </td>  
                         </tr>
               </table>

               <div>
                       <input type="submit" name="Update" value="Update">
                       <td>
                <a href="homepage.php"><input type="button" name="back" value="Return to homepage"></a>
                </td>
               </div><br>
      </form>
</body>
</html>