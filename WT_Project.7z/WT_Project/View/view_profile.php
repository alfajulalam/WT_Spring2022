<html>
    <head>
    <link rel="stylesheet" type="text/css" href="mycss.css">
    </head>
    <header>
        <h1>
            My Profile
        </h1>
    </header>
    <body> 
    <form action="" method="post">
        <table >
            <tr>
                <td>
                <h2>   Name: </h2> 
                </td>
                <td>
                    
                </td>
            </tr>
            <tr>
                <td>
                  <h2>  Email:</h2> 
                </td>
                <td>
                    
                </td>
            </tr>
            <tr>
                <td>
                    <h2>Department:</h2>
                </td>
                <td>

                </td>
            </tr>
            <tr>
                <td>
                   <h2> Designation:</h2>
                </td>
                <td>

                </td>
            </tr>
            <tr>
                <td>
                 <h2>Phone:<h2>
                </td>
                <td>

                </td>
            </tr>
            <tr>
                <td>
                    
                </td>
                <td>
                    <input type="submit" name="update" value="Update" >
                </td>
                <td>
                <a href="homepage.php"><input type="button" name="back" value="Return to homepage"></a>
                </td>
            </tr>
        </table>
    </form>

    <br>
</p>

</html>