<?php  
     include '../Controllers/emp_info.php';
     $emp = allEmp();
?>

<!DOCTYPE html>
<html>
<head>
	<title>All Employee Info</title>
     <link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
     <h1 align="center">All Employees</h1>
      <table border="1" cellspace="8" align="center" >
      	<th>Id</th>
          <th>Name</th>
          <th>Phoneno</th>
          <th>Occupation</th>
          <th>Operation</th>

<?php  
     
     foreach ($emp as $e) 
          {
               echo "<tr>";
               echo "<td>" .$e["id"]. "</td>";
               echo "<td>" .$e["name"]. "</td>";
               echo "<td>" .$e["phoneno"]. "</td>";
               echo "<td>" .$e["occ"]. "</td>";
               echo "<td>";
               echo "<div>";
               echo "<a href='./edit_emp.php?id=" .$e["id"]. "'>Update</a>";
               echo "<a href='./delete_emp.php?id=" .$e["id"]. "'>Delete</a>";
               echo "<div";
               echo "</td>";
               echo "</tr>";
          }
?>
</table>
</body>
</html>