<html>
<head>
	<title>Logout</title>
      <link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body
><?php
    session_start();

    if(session_destroy())
    {
        header("Location: login.php");
    }
?>
</body>
</html>