<?php  
    include '../Controllers/patient_info.php';
?>

<!DOCTYPE html>
<html>
<head>
     <h1>Patient</h1>
     <link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
<form action="" method="post">
            <input type="submit" name="fetch" value="Fetch Data">
        </form>
      <form action="" method="post">
      <table >
               <tr>
                         <td><h2>ID:</h2></td>
                         <td>
                              <input type="text" name="name" value="<?php echo $name; ?>">
                                <span>
                                 <?php echo $err_name;?>   
                            </span>
                         </td>
                        </tr>
                        <tr>
                         <td><h2>Name:</h2></td>
                         <td>
                              <input type="text" name="name" value="<?php echo $name; ?>">
                                <span>
                                 <?php echo $err_name;?>   
                            </span>
                         </td>
                        </tr>

                        <tr>
                        <td><h2 >Phone no:</h2></td>
                         <td>
                              <input type="text" name="phoneno" value="<?php echo $phoneno; ?>">
                                <span>
                                 <?php echo $err_phoneno;?>   
                            </span>
                         </td>                    
                        </tr>
                        <tr>
                         <td><h2 >Age:</h2></td>
                         <td>
                              <input type="text" name="age" value="<?php echo $age; ?>">
                                <span>
                                 <?php echo $err_age;?>   
                                </span>
                         </td>  

                        </tr>
                        <tr>
                         <td><h2 >Disease:</h2></td>
                         <td>
                              <input type="text" name="disease" value="<?php echo $disease; ?>">
                                <span>
                                 <?php echo $err_disease;?>   
                                </span>
                         </td>  
                        </tr>
               </table>
               <table >
                    <tr>
                         <td>
                         <h2 >Treatment:</h2></td>
                    
                         <td>
                              <input type="text" name="treatment" value="<?php echo $treatment; ?>">
                                <span>
                                 <?php echo $err_treatment;?>   
                                </span>
                         </td> 
                    </tr>
               </table>
          

               <div >
                    <h1>   <input type="submit" name="Insert" value="Insert"> </h1>
               </div><br>
               <div >
               <a href="update.php"><input type="button" name="back" value="Update"></a>
               <div><br>
               <div >
               <a href="delete.php"><input type="button" name="back" value="Delete"></a>
               <div><br>
               <td>
                <a href="homepage.php"><input type="button" name="back" value="Return to homepage"></a>
                </td>
               
      </form>
      
</body>
</html>