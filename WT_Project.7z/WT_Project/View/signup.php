<?php
	include '../Controllers/reg_controller.php';
?>

<html>
	<head>	<link rel="stylesheet" href="mycss.css"></head>
    <body >
<div>
	<h1>Sign Up</h1>
	<h5><?php echo $err_db;?></h5>
	<form action="" method="post" onsubmit="return validateUserForm()">
		<div>
			<h4>Name</h4> 
			<input type="text" id="name" name="name" value="<?php echo $name;?>">
			<br><p id="errname"></p>
			<span><?php echo $err_name;?></span>
		</div>
		<div>
			<h4>Username</h4> 
			<input type="text" id="uname" name="username" value="<?php echo $username;?>">
			<br><p id="erruname"></p>
			<span><?php echo $err_username;?></span>
		</div>
		<div>
			<h4>Email</h4> 
			<input type="text" id="email" name="email">
			<br><p id="erremail"></p>
            <span><?php echo $err_email;?></span>
		</div>
		<div>
			<h4 class="text">Password</h4> 
			<input type="password" id="pass" name="pass">
			<br><p id="errpass"></p>
            <span><?php echo $err_password;?></span>
		</div>
		<div>
			
			<input type="submit" name="signup" value="Sign Up">
		</div>
	</form>
</div>
<script type="text/javascript" src="../JS/myjs.js"></script>
</body>
</html>
