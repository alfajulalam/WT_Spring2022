<?php  
     include '../Controllers/appointment_info.php';
?>

<!DOCTYPE html>
<html>
<head>
     <tr><th></th></tr>
     <title>New Appointment</title>
     <link rel="stylesheet" type="text/css" href="mycss.css">
</head>
<body>
      <form action="" method="post" onsubmit="return hotelRoomForm()">
               <table >
                        <tr>
                         <td><h2 >Patient Name: </h2></td>
                         <td>
                              <input type="text" name="name" value="<?php echo $name; ?>">
                                <span>
                                 <?php echo $err_name;?>   
                            </span>
                         </td>
                        </tr>
                        <tr>
                         <td><h2 >Patient Email: </h2></td>
                         <td>
                              <input type="text" name="name" value="<?php echo $mail; ?>">
                                <span>
                                 <?php echo $err_mail;?>   
                            </span>
                         </td>
                        </tr>

                        <tr>
                        <td><h2>Phone No: </h2></td>
                         <td>
                              <input type="text" name="phoneno" size="50" value="<?php echo $phoneno; ?>">
                                <span>
                                 <?php echo $err_phoneno;?>   
                            </span>
                         </td>                    
                        </tr>

                        <tr>
                         <td><h2 >Disease: </h2></td>
                         <td>
                              <input type="text" name="disease" size="50" value="<?php echo $disease; ?>">
                                <span>
                                 <?php echo $err_disease;?>   
                                </span>
                         </td>  
                        </tr>
                        <tr>
                         <td><h2 >Appointment Time: </h2></td>
                         <td>
                              <input type="text" name="appointment_time" size="50" value="<?php echo $err_apt; ?>">
                                <span>
                                 <?php echo $err_apt;?>   
                                </span>
                         </td>  
                        </tr>

               </table>

               
                       <input type="submit" name="Insert" value="Insert">
               </div><br>
      </form>
      <script type="text/javascript" src="../JS/myjs.js"></script>
</body>
</html>